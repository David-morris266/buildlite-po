// client/src/POForm.jsx
import React, { useEffect, useMemo, useState } from 'react';
import CostCodeSelect from './CostCodeSelect';
import SupplierSelect from './SupplierSelect';
import JobSelect from './JobSelect';
import { listJobs } from '../api';
import './POForm.css';

const toNumber = (v) => {
  if (v == null) return 0;
  const n = parseFloat(String(v).replace(/[^0-9.\-]/g, ''));
  return Number.isFinite(n) ? n : 0;
};

const UOMS = [
  'nr','m','m2','m3','mm','cm',
  'hr','day','week',
  'ea','set','pair','thou',
  'kg','t',
  'l','gal',
  'ls'
];

export default function POForm() {
  // Supplier (id + name)
  const [supplierId, setSupplierId] = useState('');
  const [supplierName, setSupplierName] = useState('');

  // Order type (M / S / P)
  const [type, setType] = useState('M');

  // Job selection
  const [jobId, setJobId] = useState('');
  const [jobSnap, setJobSnap] = useState(null);

  // Legacy / manual job code
  const [jobCode, setJobCode] = useState('');

  // Single cost code string
  const [costCode, setCostCode] = useState('');

  const [title, setTitle] = useState('');
  const [vatRate, setVatRate] = useState(0.2);

  // Lines
  const [lines, setLines] = useState([
    { description: '', uom: 'nr', qty: '', rate: '', amount: 0 },
  ]);

  // ---- Clause state (for sub-contract / plant) ----
  const [clauseTender, setClauseTender] = useState(false);
  const [clauseTenderDate, setClauseTenderDate] = useState('');
  const [clauseTerms, setClauseTerms] = useState(false);
  const [clauseTermsVersion, setClauseTermsVersion] = useState('');
  const [clauseRAMS, setClauseRAMS] = useState(false);
  // -------------------------------------------------

  const addLine = () => {
    setLines(prev => [...prev, { description: '', uom: 'nr', qty: '', rate: '', amount: 0 }]);
  };

  const removeLine = (idx) => {
    setLines(prev => prev.filter((_, i) => i !== idx));
  };

  const updateLine = (idx, field, value) => {
    setLines(prev => {
      const next = [...prev];
      const row = { ...next[idx], [field]: value };
      const qty  = toNumber(field === 'qty'  ? value : row.qty);
      const rate = toNumber(field === 'rate' ? value : row.rate);
      row.amount = qty * rate;
      next[idx] = row;
      return next;
    });
  };

  const subtotal = lines.reduce((s, r) => s + toNumber(r.amount), 0);
  const vatAmt   = subtotal * toNumber(vatRate);
  const gross    = subtotal + vatAmt;

  // ===== Load selected job snapshot =====
  useEffect(() => {
    if (!jobId) { setJobSnap(null); return; }
    (async () => {
      try {
        const jobs = await listJobs();
        const found = (jobs || []).find(j => String(j.id) === String(jobId)) || null;
        setJobSnap(found || null);
        if (found && (found.jobNumber || found.jobCode)) {
          setJobCode(found.jobNumber || found.jobCode || '');
        } else {
          setJobCode('');
        }
      } catch {
        setJobSnap(null);
      }
    })();
  }, [jobId]);

  const projectLabel = useMemo(() => {
    if (!jobSnap) return '';
    const tag = jobSnap.jobNumber || jobSnap.jobCode || '';
    return [jobSnap.name, tag].filter(Boolean).join(' · ');
  }, [jobSnap]);

  async function savePO() {
    // Normalise costCode in case it ever becomes an object again
    const costCodeString =
      typeof costCode === 'string'
        ? costCode
        : (costCode && costCode.code) || '';

    // VALIDATION
    if (!supplierId) {
      alert('Supplier is required');
      return;
    }
    if (!costCodeString || !costCodeString.trim()) {
      alert('Cost code is required');
      return;
    }
    if (lines.length === 0 || lines.every(l => !l.description && !toNumber(l.amount))) {
      alert('Add at least one order line');
      return;
    }
    if (!['M','S','P'].includes(type)) {
      alert('Order Type must be M, S or P');
      return;
    }

    // Build clauses array from ticks
   const clauses = {
      tenderRefEnabled: clauseTender,
      tenderRefDate: clauseTenderDate,
      termsEnabled: clauseTerms,
      termsVersion: clauseTermsVersion,
      ramsRequired: clauseRAMS,
    };

    // Payload
    const body = {
      type,
      supplierId,
      supplierName,

      costRef: {
        jobId: jobSnap?.id || '',
        jobCode: jobSnap?.jobCode || jobSnap?.jobNumber || jobCode || '',
        costCode: costCodeString,
        element: ''
      },

      job: jobSnap ? {
        id: jobSnap.id,
        jobCode: jobSnap.jobCode || '',
        jobNumber: jobSnap.jobNumber || '',
        name: jobSnap.name || '',
        siteAddress: jobSnap.siteAddress || '',
        siteManager: jobSnap.siteManager || '',
        sitePhone: jobSnap.sitePhone || '',
        client: jobSnap.client || '',
        notes: jobSnap.notes || ''
      } : null,

      title: title?.trim() || (jobSnap ? `PO · ${jobSnap.name}` : ''),

      vatRateDefault: toNumber(vatRate),

      items: lines
        .filter(l => l.description || toNumber(l.amount) > 0)
        .map(l => ({
          description: l.description || '',
          uom: l.uom || 'nr',
          qty: toNumber(l.qty),
          rate: toNumber(l.rate),
          amount: toNumber(l.amount),
          costCode: costCodeString
        })),

      amount: subtotal,
      createdBy: 'david@dmcc',

      // NEW: clauses array
      clauses,
    };

    try {
      const res = await fetch('/api/po', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.message || `Save failed (${res.status})`);
      }
      const po = await res.json();
      alert(`PO ${po.poNumber || 'saved'} successfully`);

      // Reset form
      setSupplierId('');
      setSupplierName('');
      setType('M');
      setJobId('');
      setJobSnap(null);
      setJobCode('');
      setCostCode('');
      setTitle('');
      setVatRate(0.2);
      setLines([{ description: '', uom: 'nr', qty: '', rate: '', amount: 0 }]);

      // Reset clauses
      setClauseTender(false);
      setClauseTenderDate('');
      setClauseTerms(false);
      setClauseTermsVersion('');
      setClauseRAMS(false);
    } catch (e) {
      console.error(e);
      alert(e.message);
    }
  }

  return (
    <div className="po-form-container">
      <h2>New Purchase Order</h2>

      {/* Header inputs */}
      <div className="po-form-grid">
        <div>
          {/* SupplierSelect already renders its own label */}
          <SupplierSelect
            value={supplierId}
            onChange={(sel) => {
              setSupplierId(sel?.id || '');
              setSupplierName(sel?.name || '');
            }}
          />
        </div>

        <div>
          <label>Order Type</label>
          <select value={type} onChange={(e) => setType(e.target.value)}>
            <option value="M">Materials</option>
            <option value="S">Subcontract</option>
            <option value="P">Plant</option>
          </select>
        </div>

        <div>
          <label>Job</label>
          <JobSelect value={jobId} onChange={setJobId} />
          {jobSnap && (
            <div className="muted" style={{ marginTop: 4 }}>
              {projectLabel}<br />
              {jobSnap.siteAddress || ''}
              {jobSnap.siteManager ? ` · ${jobSnap.siteManager}` : ''}
              {jobSnap.sitePhone ? ` · ${jobSnap.sitePhone}` : ''}
            </div>
          )}
        </div>

        <div>
          <label>Job Code (optional)</label>
          <input
            placeholder="e.g. CO-CP-001"
            value={jobCode}
            onChange={(e) => setJobCode(e.target.value)}
          />
        </div>

        <div>
          {/* CostCodeSelect renders its own label */}
          <CostCodeSelect value={costCode} onChange={setCostCode} />
        </div>

        <div>
          <label>Title / Description</label>
          <input
            placeholder="Short PO description"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
        </div>

        <div>
          <label>VAT Rate</label>
          <select
            value={vatRate}
            onChange={(e) => setVatRate(parseFloat(e.target.value))}
          >
            <option value={0}>0%</option>
            <option value={0.05}>5%</option>
            <option value={0.2}>20%</option>
          </select>
        </div>
      </div>

      {/* Clauses section – only for Subcontract / Plant */}
      {(type === 'S' || type === 'P') && (
        <div className="po-lines-card" style={{ marginTop: 12 }}>
          <h3 style={{ marginTop: 0 }}>Contract Clauses / References</h3>

          <div className="clause-row">
            <label style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <input
                type="checkbox"
                checked={clauseTender}
                onChange={e => setClauseTender(e.target.checked)}
              />
              <span>Refer to Cotswold Oak tender enquiry dated</span>
              <input
                type="text"
                placeholder="e.g. 10/06/2025"
                value={clauseTenderDate}
                onChange={e => setClauseTenderDate(e.target.value)}
                disabled={!clauseTender}
                style={{ maxWidth: 140 }}
              />
            </label>
          </div>

          <div className="clause-row" style={{ marginTop: 6 }}>
            <label style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <input
                type="checkbox"
                checked={clauseTerms}
                onChange={e => setClauseTerms(e.target.checked)}
              />
              <span>Refer to Cotswold Oak sub-contract terms and conditions version</span>
              <input
                type="text"
                placeholder="e.g. v1.0"
                value={clauseTermsVersion}
                onChange={e => setClauseTermsVersion(e.target.value)}
                disabled={!clauseTerms}
                style={{ maxWidth: 100 }}
              />
            </label>
          </div>

          <div className="clause-row" style={{ marginTop: 6 }}>
            <label style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <input
                type="checkbox"
                checked={clauseRAMS}
                onChange={e => setClauseRAMS(e.target.checked)}
              />
              <span>RAMS must be supplied and vetted prior to start on site.</span>
            </label>
          </div>
        </div>
      )}

      {/* Lines toolbar */}
      <div className="po-form-toolbar">
        <button type="button" className="quiet" onClick={addLine}>
          + Add Line
        </button>
        <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>
          Tip: use Tab to move across, Enter to add more lines.
        </div>
      </div>

      {/* Lines table */}
      <div className="po-lines-card">
        <table className="po-lines-table">
          <thead>
            <tr>
              <th className="po-col-desc">Description</th>
              <th className="po-col-uom">UoM</th>
              <th className="po-col-qty">Qty</th>
              <th className="po-col-rate">Rate</th>
              <th className="po-col-amt">Amount</th>
              <th className="po-col-actions"></th>
            </tr>
          </thead>
          <tbody>
            {lines.map((r, idx) => (
              <tr key={idx}>
                <td>
                  <input
                    value={r.description}
                    onChange={(e) => updateLine(idx, 'description', e.target.value)}
                    placeholder="e.g. C30 concrete"
                  />
                </td>
                <td>
                  <select
                    value={r.uom}
                    onChange={(e) => updateLine(idx, 'uom', e.target.value)}
                  >
                    {UOMS.map(u => (
                      <option key={u} value={u}>{u}</option>
                    ))}
                  </select>
                </td>
                <td style={{ textAlign: 'right' }}>
                  <input
                    value={r.qty}
                    onChange={(e) => updateLine(idx, 'qty', e.target.value)}
                    inputMode="decimal"
                    placeholder="0"
                    style={{ textAlign: 'right' }}
                  />
                </td>
                <td style={{ textAlign: 'right' }}>
                  <input
                    value={r.rate}
                    onChange={(e) => updateLine(idx, 'rate', e.target.value)}
                    inputMode="decimal"
                    placeholder="0.00"
                    style={{ textAlign: 'right' }}
                  />
                </td>
                <td style={{ textAlign: 'right' }}>
                  £{toNumber(r.amount).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                </td>
                <td style={{ textAlign: 'center' }}>
                  <button
                    onClick={() => removeLine(idx)}
                    className="quiet"
                    title="Remove line"
                    style={{ width: 36 }}
                  >
                    🗑️
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Totals */}
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: '1fr 240px',
          gap: 8,
          marginTop: 12,
        }}
      >
        <div />
        <div className="po-totals">
          <div className="po-total-row">
            <span>Net</span>
            <b>
              £{subtotal.toLocaleString(undefined, { minimumFractionDigits: 2 })}
            </b>
          </div>
          <div className="po-total-row">
            <span>VAT ({(vatRate * 100).toFixed(0)}%)</span>
            <b>
              £{vatAmt.toLocaleString(undefined, { minimumFractionDigits: 2 })}
            </b>
          </div>
          <div className="po-total-row po-total-divider">
            <span>Gross</span>
            <b>
              £{gross.toLocaleString(undefined, { minimumFractionDigits: 2 })}
            </b>
          </div>
        </div>
      </div>

      {/* Save */}
      <div style={{ marginTop: 12 }}>
        <button onClick={savePO} className="primary" style={{ width: '100%' }}>
          Save Purchase Order
        </button>
      </div>
    </div>
  );
}
