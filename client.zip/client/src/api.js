// src/api.js

/* ---------- Suppliers ---------- */
export async function listSuppliers(q = '') {
  const url = q ? `/api/suppliers?q=${encodeURIComponent(q)}` : '/api/suppliers';
  const res = await fetch(url);
  if (!res.ok) throw new Error('Failed to fetch suppliers');
  return res.json(); // array
}

/* ---------- Jobs ---------- */
export async function listJobs(q = '') {
  const url = q ? `/api/jobs?q=${encodeURIComponent(q)}` : '/api/jobs';
  const res = await fetch(url);
  if (!res.ok) throw new Error('Failed to fetch jobs');
  return res.json(); // array
}

export async function getJob(id) {
  const res = await fetch(`/api/jobs/${encodeURIComponent(id)}`);
  if (!res.ok) throw new Error('Failed to fetch job');
  return res.json(); // object
}

/* ---------- POs ---------- */
export async function listPOs(params = {}) {
  const query = new URLSearchParams(params).toString();
  const res = await fetch(`/api/po${query ? `?${query}` : ''}`);
  if (!res.ok) throw new Error('Failed to fetch POs');
  return res.json(); // { items: [...] }
}

export async function getPO(number) {
  const res = await fetch(`/api/po/${encodeURIComponent(number)}`);
  if (!res.ok) throw new Error('Failed to fetch PO');
  return res.json();
}

export async function deletePO(number) {
  const res = await fetch(`/api/po/${encodeURIComponent(number)}`, { method: 'DELETE' });
  if (!res.ok) throw new Error('Failed to delete PO');
  return res.json();
}

export async function approvePO(number, body) {
  const res = await fetch(`/api/po/${encodeURIComponent(number)}/approve`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body || {}),
  });
  if (!res.ok) throw new Error('Failed to approve/reject PO');
  return res.json();
}

export async function requestApproval(number, body) {
  const res = await fetch(`/api/po/${encodeURIComponent(number)}/request-approval`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body || {}),
  });
  if (!res.ok) throw new Error('Failed to send PO for approval');
  return res.json();
}
